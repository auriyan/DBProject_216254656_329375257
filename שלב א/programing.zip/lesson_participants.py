import random
import os

# מיקום תיקיית Programing בנתיב הנכון
network_path = "C:/Networks/work/programing"  # עדכן את הנתיב הזה

# הדפסת הנתיב כדי לוודא מה קורה
print(f"Saving to: {network_path}")

# אם תיקיית Programing לא קיימת, ניצור אותה
if not os.path.exists(network_path):
    os.makedirs(network_path)

# יצירת קובץ SQL עבור lesson_participants
file_path = os.path.join(network_path, 'lesson_participants_inserts.sql')
with open(file_path, 'w') as f:
    for _ in range(400):  # 400 רשומות
        lesson_id = random.randint(1, 100)  # lesson_id אקראי מ-1 עד 100
        customer_id = random.randint(1, 400)  # customer_id אקראי מ-1 עד 400
        insert_statement = f"INSERT INTO lesson_participants (lid, cid) VALUES ({lesson_id}, {customer_id});\n"
        f.write(insert_statement)

print(f"SQL script for lesson_participants created successfully at {file_path}")
