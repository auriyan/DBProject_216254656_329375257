import shutil

# נתיב התיקייה שברצונך לדחוס
folder_path = "C:/Networks/work/programing"  # עדכן את הנתיב שלך כאן

# יצירת קובץ ZIP
zip_path = "C:/Networks/work/programing.zip"  # נתיב שמירת הקובץ ZIP
shutil.make_archive(zip_path.replace('.zip', ''), 'zip', folder_path)

print(f"ZIP file created at: {zip_path}")
