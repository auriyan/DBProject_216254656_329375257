import random
from datetime import datetime
import os

# מיקום תיקיית Programing בנתיב הנכון
network_path = "C:/Networks/work/programing"  # עדכן את הנתיב הזה

# הדפסת הנתיב כדי לוודא מה קורה
print(f"Saving to: {network_path}")

# אם תיקיית Programing לא קיימת, ניצור אותה
if not os.path.exists(network_path):
    os.makedirs(network_path)

# יצירת קובץ SQL עבור payment
file_path = os.path.join(network_path, 'payment_inserts.sql')
with open(file_path, 'w') as f:
    for payment_id in range(1, 401):  # 400 רשומות
        rental_id = random.randint(1, 400)  # rental_id אקראי מ-1 עד 400
        payment_date = datetime.now().strftime('%Y-%m-%d')  # תאריך התשלום (תאריך נוכחי)
        amount = round(random.uniform(10, 500), 2)  # סכום אקראי בין 10 ל-500
        insert_statement = f"INSERT INTO payment (payment_id, rental_id, payment_date, amount) VALUES ({payment_id}, {rental_id}, '{payment_date}', {amount});\n"
        f.write(insert_statement)

print(f"SQL script for payment created successfully at {file_path}")
